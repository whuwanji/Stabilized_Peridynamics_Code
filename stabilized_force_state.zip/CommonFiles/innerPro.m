function K = innerPro(wf, X, Y, vj, ih)
% obtain the inner product of two states X and Y
nh = size(ih,1);
m = size(X,2);
n = size(Y,2);
for i = 1:m
    for j = 1:n
        k = (i-1)*n + j;
        K(:,k) = accumarray(ih, wf.*X(:,i).*Y(:,j).*vj);
    end
end
end