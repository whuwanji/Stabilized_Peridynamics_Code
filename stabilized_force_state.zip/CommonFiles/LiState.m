function Ts = LiState(wf, X, Y, x, bc, Z, Z_, pv, ih, jh, iK)
% Li State
% Refer to
% Li, P., Hao, Z.M., Zhen, W.Q.: 
% A stabilized non-ordinary state-based peridynamic model. 
% Comput. Methods Appl. Mech. Eng. 339, 262–280 (2018)
wf0 = bc*1/2*wf./x.^3;
C = matmul(X.*[wf0,wf0,wf0],X,3,1,3);
KN = matmul(C,matmul(Z,Y-X,3,1,3),3,3,3);
SS = zeros(size(pv,1),9);
for i = 1:1:size(KN,2)
    SS(:,i) = accumarray(ih,KN(:,i).*pv(jh));
end
    SSiK = matmul(SS, iK, 3,3,3);
    ST = SSiK(ih,:) + SSiK(jh,:);
    Ts = matmul(C, Z-Z_, 3, 3, 1) + matmul(ST,X.*[wf,wf,wf],3,3,1);
end