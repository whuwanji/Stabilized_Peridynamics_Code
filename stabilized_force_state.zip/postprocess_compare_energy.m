clc; clear
folder = 'ResultFolder\';
files = {'ZeroEnergy','Ordinary','WanJi','LiPan','Silling'};
LGD = {'Zero energy', 'Ordinary','Wan','Li','Silling'};
fileName = strcat(strcat(folder, files),'.mat');
isExist = false(size(fileName));

figure(1)
for i = 1:5
    isExist(i) = exist(fileName{i}, 'file');
    if(~isExist(i))
        continue;
    else
        p = load(fileName{i});
        Wk = p.Wk * 1e-6; % 把体积乘上
        Wp = p.Wp * 1e-6;
        subplot(2,1,1)
        plot(Wk(:,1), Wk(:,2))
        hold on
        subplot(2,1,2)
        plot(Wp(:,1), Wp(:,2))
        hold on
    end
end
subplot(2,1,1)
legend(LGD(isExist),'Location','northeast','NumColumns',2)
xlabel('time'); ylabel('Knetic energy(J)')
set(gca, 'fontsize', 14, 'fontname', 'times new roman')
subplot(2,1,2)
legend(LGD(isExist),'Location','northwest','NumColumns',2)
xlabel('time'); ylabel('Potential energy(J)')
set(gca, 'fontsize', 14, 'fontname', 'times new roman')
actualEnergy = 1/2*12e6*(0.002)^2*(101*101*6*1e-6)