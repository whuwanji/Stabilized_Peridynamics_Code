function [KeS, BS] = keB_8node3D(dNdX,gW,De,detJ)
nGPT = size(dNdX,3);
eN = size(dNdX,4);
KeS = zeros(24,24,nGPT, eN);
BS = zeros(6,24,nGPT, eN);
for i = 1:1:eN
    for j = 1:1:nGPT
        B = zeros(6,24);
        B(1,1:3:end) = dNdX(1,:,j,i);
        B(2,2:3:end) = dNdX(2,:,j,i);
        B(3,3:3:end) = dNdX(3,:,j,i);
        
        B(4,1:3:end) = dNdX(2,:,j,i);
        B(4,2:3:end) = dNdX(1,:,j,i);
        
        B(5,3:3:end) = dNdX(2,:,j,i);
        B(5,2:3:end) = dNdX(3,:,j,i);
        
        B(6,1:3:end) = dNdX(3,:,j,i);
        B(6,3:3:end) = dNdX(1,:,j,i);
        
        KeGauss = B'*De*B;% 单元刚度矩阵
        KeS(:,:,j,i) = KeGauss*gW{1}(j)*gW{2}(j)*gW{3}(j)*detJ(j,i); % 组合单元刚度矩阵
        BS(:,:,j,i) = B;
    end
end
end