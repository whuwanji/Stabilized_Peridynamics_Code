function [N, dNdX, gW, detJ] = stiffnessAssembly(node, element, gaussPoint, gaussWeight, interpFun, DinterpFun)
[nN,nDim] = size(node);
[eN,eNN] = size(element);
nGP = numel(gaussPoint);
nGPT = nGP^nDim;
if(nDim==2)
    [gP1, gP2] = meshgrid(gaussPoint, gaussPoint);
    [gW1, gW2] = meshgrid(gaussWeight,gaussWeight);
    gP1 = reshape(gP1,numel(gP1),1);
    gP2 = reshape(gP2,numel(gP2),1);
    gW1 = reshape(gW1,numel(gW1),1);
    gW2 = reshape(gW2,numel(gW2),1);
    gW = {gW1,gW2};
else
    [gP1, gP2, gP3] = meshgrid(gaussPoint, gaussPoint, gaussPoint);
    [gW1, gW2, gW3] = meshgrid(gaussWeight, gaussWeight, gaussWeight);
    gP1 = reshape(gP1,numel(gP1),1);
    gP2 = reshape(gP2,numel(gP2),1);
    gP3 = reshape(gP3,numel(gP3),1);
    gW1 = reshape(gW1,numel(gW1),1);
    gW2 = reshape(gW2,numel(gW2),1);
    gW3 = reshape(gW3,numel(gW3),1);
    gW = {gW1,gW2,gW3};
end
N = zeros(nGPT, eNN);
dN = zeros(nDim, eNN, nGPT);
for i = 1:1:nGPT
    if(nDim==2)
        N(i,:) = interpFun(gP1(i),gP2(i));
        dN(:,:,i) = DinterpFun(gP1(i), gP2(i));
    elseif(nDim==3)
        N(i,:) = interpFun(gP1(i),gP2(i), gP3(i));
        dN(:,:,i) = DinterpFun(gP1(i), gP2(i), gP3(i));
    end
end
dNdX = zeros(nDim,eNN,nGPT,eN);
detJ = zeros(nGPT,eN);
for i = 1:1:eN
    ecoor = node(element(i,:),:);
    for j = 1:1:nGPT
        Jac = dN(:,:,j)*ecoor;
        dNdX(:,:,j,i) = Jac\dN(:,:,j);
        detJ(j,i) = det(Jac);
    end
end
end