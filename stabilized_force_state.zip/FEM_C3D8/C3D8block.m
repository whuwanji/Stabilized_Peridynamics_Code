function [node, elem] = C3D8block(side, ndiv)
% construct c3d8 elements
a = side(1);
b = side(2);
c = side(3);
nx = ndiv(1)+1;
ny = ndiv(2)+1;
nz = ndiv(3)+1;
x = linspace(0,a,nx);
y = linspace(0,b,ny);
z = linspace(0,c,nz);
elem = zeros((nx-1)*(ny-1)*(nz-1), 8);
for i = 1:nx-1
    for j = 1:ny-1
        for k = 1:nz-1
            p = [0, 1, 1, 0, 0, 1 ,1, 0];
            q = [0, 0, 1, 1, 0, 0 ,1, 1];
            r = [0, 0, 0, 0, 1, 1 ,1, 1];
            n = (i + p -1)*(ny)*(nz) + (j + q -1)*(nz) + k + r;
            elem ( (i-1)*(ny-1)*(nz-1) + (j-1)*(nz-1)+ k,: ) = n;
        end
    end
end
node = zeros((nx)*(ny)*(nz), 3);
for i = 1:nx
    for j = 1:ny
        for k = 1:nz
            p = (i -1)*ny*nz + (j -1)*nz + k;
            node(p,:) = [x(i), y(j), z(k)];
        end
    end
end
end