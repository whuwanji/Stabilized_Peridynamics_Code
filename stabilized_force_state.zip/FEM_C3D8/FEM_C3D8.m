clc;clear
% Programmed by Wan Ji
% Version
tic
ksi0 = [-1, 1, 1, -1, -1, 1, 1, -1];
eta0 = [-1, -1, 1, 1, -1, -1, 1, 1];
zeta0 = [-1, -1, -1, -1, 1, 1, 1, 1];
N = @(ksi, eta, zeta)0.125*(1+ksi0*ksi).*(1+eta0*eta).*(1+zeta0.*zeta);
dNdX = @(ksi, eta, zeta) [
    0.125*ksi0.*(1+eta0*eta).*(1+zeta0.*zeta);
    0.125*eta0.*(1+ksi0*ksi).*(1+zeta0.*zeta);
    0.125*zeta0.*(1+ksi0*ksi).*(1+eta0*eta);
    ];
% 1/8 Model
a = 0.5;
b = 0.5;
c = 0.03;
rad = a/5;
ndivx = 50;
ndivy = 50;
ndivz = 3;
[node, elem] = C3D8block([a,b,c], [ndivx,ndivy,ndivz]);

elemCenter = zeros(size(elem,1),3);
for i = 1:1:size(elem,1)
    p = node(elem(i,:),:);
    elemCenter(i,:) = N(0,0,0)*p;
end
[node, elem] = deleteElement(elem, node, vecnorm(elemCenter,2,2) < rad);

elementNum = size(elem, 1);
nodeNum = size(node, 1);
elemNodeNum = size(elem, 2);
dof = size(node, 2); % Field Variables: U1 U2 U3
elementKeSize = (elemNodeNum*dof)^2;
totDOF = nodeNum*dof;
% patchC3D8(elem, node, node(:,2))
% axis equal

spStiffMat = zeros(elementNum*elemNodeNum^2*dof^2,3);
PosTot = zeros(elementNum*elemNodeNum^2*dof^2,2);
PosVal = zeros(elementNum*elemNodeNum^2*dof^2,1);
GP = [-1/sqrt(3), 1/sqrt(3)];
WF = [1,1];
nGP = numel(GP);
pr = 0.3; % 泊松比
pr0 = pr/(1-2*pr);
emod = 12e6; % 弹性模量
De = emod/(1+pr)*[
    1+pr0, pr0, pr0, 0, 0, 0, 0, 0, 0;
    pr0, 1+pr0, pr0, 0, 0, 0, 0, 0, 0;
    pr0, pr0, 1+pr0, 0, 0, 0, 0, 0, 0;
    0, 0, 0, 1, 0, 0, 0, 0, 0;
    0, 0, 0, 0, 1, 0, 0, 0, 0;
    0, 0, 0, 0, 0, 1, 0, 0, 0;
    0, 0, 0, 0, 0, 0, 1, 0, 0;
    0, 0, 0, 0, 0, 0, 0, 1, 0;
    0, 0, 0, 0, 0, 0, 0, 0, 1;
    ];% 弹性张量的形式
De2 = emod/(1+pr)*[
    1+pr0, pr0, pr0, 0, 0, 0;
    pr0, 1+pr0, pr0, 0, 0, 0;
    pr0, pr0, 1+pr0, 0, 0, 0;
    0, 0, 0, 1/2, 0, 0;
    0, 0, 0, 0, 1/2, 0;
    0, 0, 0, 0, 0, 1/2;
    ];% 弹性张量的形式
Vol = zeros(elementNum,1);
[Ninterp, dNdX, gW, detJ] = stiffnessAssembly(node, elem, GP, WF, N, dNdX);
[KeS, BS] = keB_8node3D(dNdX,gW,De2,detJ);

for i = 1:1:size(elem,1)
    enode = elem(i,:); % 单元的四个结点
    %   ed = d(enode,1); % 四个结点的损伤值
    ecoor = node(enode,:); % 四个结点的坐标
    Ke = zeros(numel(enode)*dof); % 单元刚度矩阵预设
    nPos = repmat(dof*(enode - 1),dof,1) + repmat((1:1:dof)',1,numel(enode)); % 单元刚度组装指向向量
    nPos = reshape(nPos,numel(nPos),1);
    
    for j = 1:1:size(dNdX,3)
        Ke = Ke + KeS(:,:,j,i);
    end
    [pos1, pos2] = meshgrid(nPos,nPos);
    kePos1 = reshape(pos1,elementKeSize,1);
    kePos2 = reshape(pos2,elementKeSize,1);
    keVal = reshape(Ke,elementKeSize,1);
    pstart = (i-1)*elementKeSize + 1;
    pend = i*elementKeSize;
    PosTot(pstart:1:pend,:) = [kePos1, kePos2];
    PosVal(pstart:1:pend,1) = keVal;
end
Ktot = accumarray(PosTot,PosVal,[totDOF,totDOF],@sum,[],true);

pset1 = find(abs((node(:,1)-0))<0.00001);
pset2 = find(abs((node(:,2)-0))<0.00001);
pset3 = find(abs((node(:,3)-0))<0.00001);
pset4 = find(abs((node(:,2)-b))<0.00001);
uc = [
    pset1 , ones(size(pset1 )), 0*ones(size(pset1 ));
    pset2, 2*ones(size(pset2)), 0*ones(size(pset2));
    pset3, 3*ones(size(pset3)), 0*ones(size(pset3));
    pset4, 2*ones(size(pset4)), 0.001*ones(size(pset4));
    ]; % 边界条件

nuc = size(uc,1);
G = sparse((1:1:nuc),dof*(uc(:,1)-1)+uc(:,2),ones(nuc,1),nuc,totDOF);
Lambda = uc(:,3);
F = zeros(nodeNum*dof,1); % 力向量
U = [Ktot,G';G,sparse(nuc,nuc)]\[F;Lambda]; % 求解位移
U = U(1:1:totDOF,1);
U2 = U(2:dof:end,1);

figure(1)
clf
s = find(node(:,1)==0&node(:,3)==0);
X2 = [-node(s,2); node(s,2)];
U2_ = [-U2(s,1); U2(s,1)];
[X2,IDX] = sort(X2);
U2_ = U2_(IDX);
plot(X2,U2_ ,'r')
xlabel('y-axis')
ylabel('U_y')
set(gca, 'fontsize', 16, 'fontname', 'times new roman')
XU = [X2,U2_];
save('C3D8FEMRES.txt','XU','-ascii')
toc
