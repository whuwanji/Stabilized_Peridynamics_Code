function [node, elem] = deleteElement(elem, node, selectedEle)
% 删除一些不满足要求的单元
elem = elem(~selectedEle,:);
m = size(elem,1);
n = size(elem,2);
evec = reshape(elem, numel(elem),1);
[p, ~, r]= unique(evec);
node = node(p,:);
nodeNum = size(node,1);
s = (1:nodeNum)';
elem = reshape(s(r),m,n);
end