clc; clear
folder = 'ResultFolder\';
files = {'ZeroEnergy.txt','Ordinary.txt','Silling.txt','WanJi.txt','LiPan.txt'};
LGD = {'Zero energy', 'Ordinary', 'Silling', 'Wan', 'Li', 'FEM'};
fileName = [strcat(folder, files),'FEM_C3D8\C3D8FEMRES.txt'];
isExist = false(size(fileName));
for i = 1:numel(fileName)
    isExist(i) = exist(fileName{i}, 'file');
    if(~isExist(i))
        continue;
    else
        p = load(fileName{i});
        y = p(:,1);
        uy = p(:,2);
        plot(y, uy)
        hold on
    end
end
legend(LGD(isExist),'Location','northwest','NumColumns',2)
xlabel('y'); ylabel('u_y')
set(gca, 'fontsize', 14, 'fontname', 'times new roman')