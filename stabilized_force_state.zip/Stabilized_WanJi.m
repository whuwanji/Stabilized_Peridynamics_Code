function Stabilized_WanJi
% 本程序是一个圆孔板的拉伸试验
% 用了Non-ordinary State-based 方法
% 零能模式控制采用Wan J, Chen Z, Chu X, et al. 2019 的文章
% Improved method for zero-energy mode suppression in peridynamic correspondence model
% Programmed by Wan Ji
% Date 2021/03/29
addpath('CommonFiles')
resultFolder = 'ResultFolder\';
length = 1;
width = 1.06;
height = 0.06;
ndivx = 100;
ndivy = 106;
ndivz = 6;
mvalue = 3.015;
delta = mvalue * length/ndivx;
[coor, pv, ih, jh, ~] = regFastNewHorizon([length,width,height], [ndivx,ndivy,ndivz],3.015 , 1);
rad = length/10.0;
% 打一个圆孔
[coor, pv, ih, jh, ~]=modifiedModel(coor(:,1).^2 + coor(:,2).^2 >= rad*rad, coor, pv, ih, jh);
% 相对位置态
X = coor(jh,:) - coor(ih,:);
x = vecnorm(X,2,2); % 键长
wf = exp(-x.^2/delta^2); % 高斯型权函数
K = innerPro(wf,X,X,pv(jh),ih); % 形状张量shape tensor
iK = ivK3D(K);


dt = 1e-6;

upnode = coor(:,2)>width/2-3.1*width/ndivy;
downnode = coor(:,2)<-width/2+3.1*width/ndivy;

dis = zeros(size(coor));
dx = length/ndivx;
emod = 12e6;

bc = 12.0d0 * emod / (pi * (delta^4));
massvec = 0.25d0 * dt * dt * ((4.0d0/3.0d0)*pi*(delta)^3) * bc / dx;
bforce = zeros(size(coor));
velhalfold = zeros(size(coor));

pforceold = zeros(size(coor));
nt = 1000;
UY = 0.001; % UY方向拉0.001

% 极其重要的，当为1时，不会抑制零能模式
withZeroEngyMode = 0;

Wp = NaN(nt,3); % 动态松弛时，内力变形能量
Wk = NaN(nt,2); % 动态松弛时，动能

for tt = 1:1:nt
    fprintf('tt=%d\n',tt);
    
    dis(upnode,2) = UY/(nt*dt)*dt*tt;
    dis(downnode,2) = -UY/(nt*dt)*dt*tt;
    
    % 显示UY云图（散点图）
    if(mod(tt,50)==0)
        figure(20)
        scatter3(coor(:,1), coor(:,2), coor(:,3), 10, dis(:,2),'filled')
        axis equal
        colormap(jet(20))
        colorbar
        pause(0.00000001)
    end
    
    % 变形态
    Y = X + dis(jh,:) - dis(ih,:);
    K = innerPro(wf,Y,X,pv(jh),ih); % 形状张量（变形后）
    F = matmul(K, iK, 3,3,3); % 变形梯度张量
    Z = Y - matmul(F(ih,:),X,3,3,1); % 非均匀变形态 Z
    Z_ = -Y - matmul(F(jh,:),-X,3,3,1); % 非均匀变形态 Z'
    
    E = [F(:,1)-1, (F(:,2)+F(:,4))/2, (F(:,3)+F(:,7))/2,...
        (F(:,2)+F(:,4))/2, F(:,5)-1, (F(:,6)+F(:,8))/2,...
        (F(:,3)+F(:,7))/2,(F(:,6)+F(:,8))/2,F(:,9)-1]; % 格林应变张量
    pr = 0.3; % 泊松比
    pr0 = pr/(1-2*pr);
    emod = 12e6; % 弹性模量
    De = emod/(1+pr)*[
        1+pr0, 0, 0, 0, pr0, 0, 0, 0, pr0;
        0, 1, 0, 0, 0, 0, 0, 0, 0;
        0, 0, 1, 0, 0, 0, 0, 0, 0;
        0, 0, 0, 1, 0, 0, 0, 0, 0;
        pr0, 0, 0, 0, 1+pr0, 0, 0, 0, pr0;
        0, 0, 0, 0, 0, 1, 0, 0, 0;
        0, 0, 0, 0, 0, 0, 1, 0, 0;
        0, 0, 0, 0, 0, 0, 0, 1, 0;
        pr0, 0, 0, 0, pr0, 0, 0, 0, 1+pr0;
        ];% 弹性张量的形式
    % Ts = LiState(wf, X, Y, x, bc/delta, Z, Z_, pv, ih, jh, iK);
    Ts  = WanState(wf, De, iK, ih, jh, Z, Z_);
    S = (De*E')'; % 柯西应力张量
    SiK = matmul(S, iK, 3,3,3);
    ST = SiK(ih,:) + SiK(jh,:);
    Tbfore = matmul(ST,X.*[wf,wf,wf],3,3,1); % 原先力态
    if(withZeroEngyMode==1) % 如果需要有零能模式存在，则不附加力态
        T =  Tbfore;
    else
        T =  Tbfore+Ts;
    end
    BondF(:,1) =  accumarray( ih, T(:,1).*pv(jh,1));
    BondF(:,2) =  accumarray( ih, T(:,2).*pv(jh,1));
    BondF(:,3) =  accumarray( ih, T(:,3).*pv(jh,1));
    pforce = BondF;
    
    % 动态松弛法，参照Madenci的程序
    q = abs(velhalfold)>1e-12;
    cn1 = - sum(sum(dis(q) .* dis(q) .* (pforce(q) / massvec - pforceold(q) / massvec) ./ (dt * velhalfold(q))));
    cn2 = sum(sum(dis.*dis));
    if(abs(cn2)>1e-12)
        if ((cn1 / cn2) > 0.0)
            cn = 2.0 * sqrt(cn1 / cn2);
        else
            cn = 0.0;
        end
    else
        cn = 0.0;
    end
    if (cn > 2.0d0)
        cn = 1.9d0;
    end
    
    if (tt==1)
        velhalf = 1.0d0 * dt / massvec * (pforce + bforce) / 2.0;
    else
        velhalf = ((2.0d0 - cn * dt) * velhalfold + 2.0 * dt / massvec * (pforce + bforce)) / (2.0 + cn * dt);
    end
    % 时间积分
    vel = 0.5d0 * (velhalfold + velhalf);
    dis = dis + velhalf * dt;
    velhalfold = velhalf;
    pforceold = pforce;
    vel(upnode,2) = 1;
    vel(downnode,2) = -1;
    
    % 计算能量
    W_potential_dens = sum(T.*(Y-X)*0.25.*[pv(jh),pv(jh),pv(jh)],2);
    W_potential = accumarray(ih,W_potential_dens);
    Wp(tt,1) = tt;
    Wk(tt,1) = tt;
    Wp(tt,2) = sum(W_potential(~upnode&(~downnode)));
    Wk(tt,2) = sum(sum((0.5*massvec*vel(~upnode&(~downnode),:).^2)));
    WpTs = sum(Ts.*(Y-X)*0.25.*[pv(jh),pv(jh),pv(jh)],2);
    WpTs = accumarray(ih,WpTs);
    Wp(tt,3) = sum(WpTs(~upnode&(~downnode)));
    % 显示能量曲线
    if(mod(tt,50)==0)
        figure(21)
        clf
        plot(Wp(1:tt,1),Wp(1:tt,2),'r-')
        hold on
        plot(Wk(1:tt,1),Wk(1:tt,2),'b-')
        xlabel('Step')
        ylabel('Energy')
        legend('W_{potential}','W_{kinetic}','location','Northwest');
        set(gca, 'fontsize', 16, 'fontname', 'times new roman')
        if(tt==nt)
            hold off;
        end
        pause(0.00000001)
        figure(25)
        clf
        plot(Wp(1:tt,1),Wp(1:tt,3)./Wp(1:tt,2)*100,'r-')
        xlabel('Step')
        ylabel('Energy Ratio(T_s/T_{total})')
        set(gca, 'fontsize', 16, 'fontname', 'times new roman')
        if(tt==nt)
            hold off;
        end
        pause(0.00000001)
    end
    dis(upnode,2) = UY/(nt*dt)*dt*tt;
    dis(downnode,2) = -UY/(nt*dt)*dt*tt;
end
% 记录特征位置的位移
s =abs(coor(:,1))<length/ndivx-0.0001&abs(coor(:,2))<=0.5&abs(coor(:,3))<=0.00001;
s = find(s);
res = [coor(s,2),dis(s,2)];
save([resultFolder,'WanJi.txt'],'res','-ascii')
save([resultFolder,'WanJi'], 'Wp', 'Wk', 'WpTs', 'dis', 'coor')
end